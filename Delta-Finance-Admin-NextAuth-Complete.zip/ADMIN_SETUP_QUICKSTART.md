# Delta Finance - Administrator setup (testnet MVP)

This package implements the Prisma seed, the requested package.json seed
command, and a working NextAuth Credentials route connected to the existing
Delta Finance dashboard authorization. Netlify itself does not host Postgres.

## 1. Install and connect to PostgreSQL

On your own development computer (or another trusted machine):

1. Extract this package and open a terminal in the folder containing `package.json`.
2. Run `npm install`. This creates a NEW `package-lock.json` consistent with the
   new authentication dependencies. **Remove the old GitHub lockfile before
   copying the new code**, then commit the regenerated lockfile.
3. Copy `.env.example` to `.env` and set a reachable PostgreSQL `DATABASE_URL`.
4. Generate strong random values for both `SESSION_SECRET` and `NEXTAUTH_SECRET`;
   set `NEXTAUTH_URL` to your app's public HTTPS URL on Netlify (for local
   development, `http://localhost:3000`). Do not commit `.env`.

## 2. Initialize schema and seed admin

Run the commands on the machine with your real database URL available:

```sh
npx prisma generate
npx prisma db push
npx prisma db seed
```

Prisma schema already contains `User.role` and the `Role.ADMIN` enum.
`prisma/seed.ts` creates `username=admin`, `email=admin`, bcrypt-hashes the
initial password using 12 rounds, and creates the Administrator user with
Prisma `upsert`. In development the initial password defaults to `robotman`.
For a production-mode seed, explicitly provide `ADMIN_SEED_PASSWORD`.

**PowerShell** (Windows, for an isolated Testnet demo only):

```powershell
$env:ADMIN_SEED_PASSWORD = 'robotman'
npx prisma db seed
Remove-Item Env:ADMIN_SEED_PASSWORD
```

**Bash** (Linux/macOS, for an isolated Testnet demo only):

```sh
ADMIN_SEED_PASSWORD='robotman' npx prisma db seed
```

An existing administrator's password is not reset on re-seeding. If the
`admin` account already exists, the initial credential is its *current*
password, not necessarily `robotman`.

## 3. Configure and deploy Netlify

- Project → Environment variables: `DATABASE_URL`, `SESSION_SECRET`,
  `NEXTAUTH_SECRET`, `NEXTAUTH_URL`, `APP_URL`, `INTERNAL_URL`, and the Xaman,
  Privy and agent keys required for other features. Runtime Functions must
  receive these values. Never expose keys in screenshots.
- Keep `npm run build` as the build command and `.next` as publish directory.
- Push source files (not the ZIP) to the root of the GitHub repository.
- Delete the **old** `package-lock.json` in GitHub and preferably replace it
  with the regenerated lockfile from `npm install`.
- Trigger a new deploy, then check Deploy log for Next.js and function output.

## 4. Verify login and HITL permissions

1. Open the deployed site, select password sign-in, enter username `admin` and
   the seed password.
2. The dashboard should display the **Administrator** role; the server reloads
   role data from PostgreSQL on authorized requests.
3. For a `PENDING_HITL` transaction, an admin can request the approval flow,
   but **a valid one-time secret code and an Xaman signature by a recognized
   administrator wallet are also required**. The seeded password account has no
   XRPL address by default. Configure `ADMIN_XRPL_ADDRESSES` and sign in with
   that Xaman account before attempting the final signature.

## Important security and validation limitations

`robotman` is intentionally the requested demonstration password and is **not
safe for production**. Do not run the seed against a real-money system with
that password. Add password rotation, MFA, rate limiting, a wallet-linking
workflow and independent authorization review before handling real funds.
The app's payment queue also requires distributed locking on serverless hosts.

The full Next.js build, live PostgreSQL seed and external XRPL/Xaman/Privy/t54
integrations could not be executed in the preparation environment. npm
registry resolution was unavailable, so this archive omits the previous
incompatible `package-lock.json` rather than shipping a lock that breaks
`npm ci`. Once dependencies are accessible, run `npm install`, `npm run typecheck`, `npm test`, and `npm run build` before deploying real data.
